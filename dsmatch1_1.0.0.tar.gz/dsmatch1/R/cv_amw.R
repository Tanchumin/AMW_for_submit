cv_amw<-function(ya,Xmat,Trt,z,foldsize=5,ps,pg,M){

  size=dim(Xmat)[1]
  p=dim(Xmat)[2]
  loc.1 <- which(Trt == 1)
  loc.0 <- which(Trt == 0)

  if(ps==TRUE){psm=z
  }else{
    psm=Xmat}

  if(pg==TRUE){pgm=z
  }else{
    pgm=Xmat}

  cvData=cbind(Trt,ya,psm,pgm,Xmat)
  #Create 5 equally size folds
  yourdata <- cut(seq(1,nrow(cvData)),breaks=foldsize,labels=FALSE)
  #Perform 5 fold cross validation
  r2=c(0,0,0,0,0)
  co=rep(0,p)

  for(iii in 1:foldsize){
    #Segement your data by fold using the which() function
    testIndexes <- which(yourdata==iii,arr.ind=TRUE)
    testData <- cvData[testIndexes, ]
    trainData <- cvData[-testIndexes, ]

    train_ya=trainData[,2]
    train_Trt=trainData[,1]
    train_loc.1=which(train_Trt == 1)
    train_loc.0=which(train_Trt == 0)
    train_psm=trainData[,3:(3+p-1)]
    train_pgm=trainData[,(3+p):(3+2*p-1)]

    test_ya=testData[,2]
    test_Trt=testData[,1]
    test_loc.1=which(test_Trt == 1)
    test_loc.0=which(test_Trt == 0)
    test_psm=testData[,3:(3+p-1)]
    test_pgm=testData[,(3+p):(3+2*p-1)]
    test_X=testData[,(3+2*p):(3+3*p-1)]

    # build for matching
    full_ya=cvData[,2]
    full_Trt=cvData[,1]
    full_psm=cvData[,3:(3+p-1)]
    full_pgm=cvData[,(3+p):(3+2*p-1)]

    lm1.out <- glm(train_ya[train_loc.1] ~ train_pgm[train_loc.1, ])
    lm0.out <- glm(train_ya[train_loc.0] ~ train_pgm[train_loc.0, ])
    glm_pg1 <- cbind(1,  full_pgm)[,which(!is.na(lm1.out$coefficients))] %*% lm1.out$coefficients[which(!is.na(lm1.out$coefficients))]
    glm_pg0 <- cbind(1,  full_pgm)[,which(!is.na(lm0.out$coefficients))] %*% lm0.out$coefficients[which(!is.na(lm0.out$coefficients))]
    glm_pg<-cbind(glm_pg0,glm_pg1)

    glm.out <- glm(train_Trt ~ train_psm, family = binomial(link = "logit"))
    pro=exp(cbind(1,full_psm)%*%glm.out$coefficients)
    glm_ps=pro/(pro+1)
  #  glm_ps <- predict(glm.out,data.frame(x=full_psm),type="response")
    # regularization for scores which can be used in matching
    glm_ps1<- cbind(1, full_psm)[,which(!is.na(glm.out$coefficients))] %*% glm.out$coefficients[which(!is.na(glm.out$coefficients))]
    glm_pg0=(glm_pg0-mean(glm_pg0))/sd(glm_pg0)
    glm_pg1=(glm_pg1-mean(glm_pg1))/sd(glm_pg1)

    glm_psr=(glm_ps1-mean(glm_ps1))/sd(glm_ps1)
    glm_pgr<-cbind(glm_pg0,glm_pg1)

    k=dsmatchATE2(full_ya,full_Trt, ps = glm_psr, pg = glm_pgr,M=M)$Kiw.ds
   # print(sum(k))
    k=(k[testIndexes]-1)/M+1


    #remake ps score
    test_ps=rep(0,size/foldsize)
    test_ps[test_loc.1]=1/k[test_loc.1]
    test_ps[test_loc.0]=1-(1/k[test_loc.0])
    test_pg1=glm_pg[testIndexes,2]
    test_pg0=glm_pg[testIndexes,1]

   #   r2[1]=r2[1]+sum((test_Trt-test_ps)^2)

   #   r2[2]=r2[2]+sum(((test_Trt[test_loc.1]-test_ps[test_loc.1])*(test_ya[test_loc.1]-test_pg1[test_loc.1]))^2)+
    #             sum(((test_Trt[test_loc.0]-test_ps[test_loc.0])*(test_ya[test_loc.0]-test_pg0[test_loc.0]))^2)

   #   r2[3]=r2[3]+sum(test_Trt*test_pg1*k)-
    #             sum((1-test_Trt)*test_pg0*k)

      r2[4]=r2[4]+sum((test_Trt*test_pg1*k)-
        ((1-test_Trt)*test_pg1*k))
      r2[5]=r2[5]+sum((test_Trt*test_pg0*k)-((1-test_Trt)*test_pg0*k))

     for(ss in 1:p){
       co[ss]=co[ss]+sum((test_Trt*test_X[,ss]*k)-
                         ((1-test_Trt)*test_X[,ss]*k))
     }

  }


  loc.1 <- which(Trt == 1)
  loc.0 <- which(Trt == 0)
  lm1.out <- glm(ya[loc.1] ~ pgm[loc.1, ])
  lm0.out <- glm(ya[loc.0] ~ pgm[loc.0, ])
  glm_pg1 <- cbind(1, pgm)[,which(!is.na(lm1.out$coefficients))] %*% lm1.out$coefficients[which(!is.na(lm1.out$coefficients))]
  glm_pg0 <- cbind(1, pgm)[,which(!is.na(lm0.out$coefficients))] %*% lm0.out$coefficients[which(!is.na(lm0.out$coefficients))]
  glm_pg<-cbind(glm_pg0,glm_pg1)


  glm.out <- glm(Trt ~ psm, family = binomial(link = "logit"))
  #glm_ps<-cbind(1,Xmat)%*%glm.out$coefficients
  pro=exp(cbind(1,psm)%*%glm.out$coefficients)
  glm_ps=pro/(pro+1)

  glm_ps1<- cbind(1, psm)[,which(!is.na(glm.out$coefficients))] %*% glm.out$coefficients[which(!is.na(glm.out$coefficients))]

  glm_pg0=(glm_pg0-mean(glm_pg0))/sd(glm_pg0)
  glm_pg1=(glm_pg1-mean(glm_pg1))/sd(glm_pg1)
  glm_psr=(glm_ps1-mean(glm_ps1))/sd(glm_ps1)
  glm_pgr<-cbind(glm_pg0,glm_pg1)

  k=dsmatchATE2(ya,Trt, ps = glm_psr, pg = glm_pgr,M=M)$Kiw.ds
  k=(k-1)/M+1
  # print(k)
  #no split version


  r2[1]=sum((Trt*glm_pg[,2]*k)-
                    ((1-Trt)*glm_pg[,2]*k))^2+sum((Trt*glm_pg[,1]*k)-((1-Trt)*glm_pg[,1]*k))^2


  co1=rep(0,p)
   for(ss in 1:p){
    co1[ss]=co[ss]+sum((Trt*Xmat[,ss]*k)-
                        ((1-Trt)*Xmat[,ss]*k))
  }


  r3=c((r2[4]^2+r2[5]^2),sum(co^2),r2[1],sum(co1^2))


  return(r3)


}
