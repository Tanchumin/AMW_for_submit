DoubleHello = function(a = NULL){
  if(is.null(a)){
    hello()
  }
  hello()
  hello()
}
