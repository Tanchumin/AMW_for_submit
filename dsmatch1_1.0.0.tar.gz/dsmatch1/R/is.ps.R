is.ps = function(ps, n){
  if(length(ps) == n){
    return(TRUE)
  }else{
    return(FALSE)
  }
}