dsmatchATE2 = function(ya, Trt,ps=NULL ,pg=NULL,M=1 ,model="dsm"){


  n <- length(ya)
  trtnumber <- 2 # number of treatment levels
  trtlevels <- c(1,0) # all treatment levels
 # print(sum(Trt))
  pertrtlevelnumber <- table(Trt)
#  print(pertrtlevelnumber)
  Kiw.ds <- c()
  original=seq(1,n,1)

  if (model=="dsm"){

  doublescore <- cbind(pg, ps)
  dmean <- apply(doublescore, 2, mean)
  dse <- apply(doublescore, 2, sd)
  doublescore <- cbind((pg[,1] - dmean[1]) / dse[1],
                       (pg[,2] - dmean[2]) / dse[2],
                       (ps - dmean[3]) / dse[3])

  doublescore1=cbind(doublescore[,2],doublescore[,3])
  doublescore0=cbind(doublescore[,1],doublescore[,3])
  # print(doublescore0)

  for (kk in 1:trtnumber) {
    thistrt <- trtlevels[kk]
    if (kk == 1) {

      fromto <- (1:(pertrtlevelnumber[kk]*M))
      A1 <- Trt != thistrt
      out1 <- Matching::Match(Y = ya, Tr = A1, X = doublescore0,
                              distance.tolerance = 0, ties = FALSE, Weight = 2,M=M)
      mdata1 <- out1$mdata
      #  print(mdata1)
      ya1original=sum(ya[which(Trt == thistrt)])/n
      ya1imputation=sum(mdata1$Y[which(mdata1$Tr == 0)])/(M*n)

      Kiw.ds<- out1$index.control
      #  print(out1$index.control)
      #  bias.mu0 <- sum(mu0.ds[out1$index.control] - mu0.ds[out1$index.treated]) / n
    }
    if (kk > 1) {

      fromto <- ((pertrtlevelnumber[kk-1]*M+1):(n*M))
      A1 <- Trt != thistrt
      out2 <- Matching::Match(Y = ya, Tr = A1, X = doublescore1,
                              distance.tolerance = 0, ties = FALSE, Weight = 2,M=M)
      #   bias.mu1 <- sum(mu1.ds[out1$index.control] - mu1.ds[out1$index.treated]) / n
      #   print(out1$index.control)
      mdata1 <- out2$mdata
      ya0original=sum(ya[which(Trt == thistrt)])/n
      ya0imputation=sum(mdata1$Y[which(mdata1$Tr == 0)])/(M*n)

      Kiw.ds=c(Kiw.ds,out2$index.control)
    }



    # bias correction for mu
    #index.control/treated is index after matching

  }

  Kiw.ds=c(Kiw.ds,seq(1,n,1))
  Kiw.ds=table(Kiw.ds)
  y=ya1imputation+ya1original-ya0original-ya0imputation
  }
  else{
    psscore <- ps
    dmean <- mean(psscore)
    dse <- sd(psscore)
    doublescore <- (psscore - dmean) / (dse)

    for (kk in 1:trtnumber) {
      thistrt <- trtlevels[kk]
      if (kk == 1) {

        fromto <- (1:(pertrtlevelnumber[kk]*M))
        A1 <- Trt != thistrt
        out1 <- Matching::Match(Y = ya, Tr = A1, X = doublescore,
                                distance.tolerance = 0, ties = FALSE, Weight = 2,M=M)
        mdata1 <- out1$mdata
        #  print(mdata1)
        ya1original=sum(ya[which(Trt == thistrt)])/n
        ya1imputation=sum(mdata1$Y[which(mdata1$Tr == 0)])/(M*n)

        Kiw.ds<- out1$index.control
        #  print(out1$index.control)
        #  bias.mu0 <- sum(mu0.ds[out1$index.control] - mu0.ds[out1$index.treated]) / n
      }
      if (kk > 1) {

        fromto <- ((pertrtlevelnumber[kk-1]*M+1):(n*M))
        A1 <- Trt != thistrt
        out2 <- Matching::Match(Y = ya, Tr = A1, X = doublescore ,
                                distance.tolerance = 0, ties = FALSE, Weight = 2,M=M)
        #   bias.mu1 <- sum(mu1.ds[out1$index.control] - mu1.ds[out1$index.treated]) / n
        #   print(out1$index.control)
        mdata1 <- out2$mdata
        ya0original=sum(ya[which(Trt == thistrt)])/n
        ya0imputation=sum(mdata1$Y[which(mdata1$Tr == 0)])/(M*n)

        Kiw.ds=c(Kiw.ds,out2$index.control)
      }
    }
    Kiw.ds=c(Kiw.ds,seq(1,n,1))
    Kiw.ds=table(Kiw.ds)
    y=ya1imputation+ya1original-ya0original-ya0imputation
}
  return(list(Kiw.ds=Kiw.ds,y=y))


}

#k=(Kiw.ds-1)/M+1
#ate=0
#for(ii in 1:sample_size){
 # ate=ate+(Trt[ii]*ya[ii]*k[ii])-((1-Trt[ii])*ya[ii]*k[ii])

  #}
#causaleffect[i,5]=ate/sample_size

#test_ps[loc.1]=1/k[loc.1]
#test_ps[loc.0]=1-(1/k[loc.0])

#(sum(Trt[loc.1]*ya[loc.1]/test_ps[loc.1])-sum((1-Trt[loc.0])*ya[loc.0]/(1-test_ps[loc.0])))/1000

