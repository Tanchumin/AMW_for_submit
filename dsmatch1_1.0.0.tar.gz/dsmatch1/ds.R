

library(randomForest)
library(xgboost)

load("~/Desktop/dsmatch-master/data copy/co_IHAD.Rdata")
load("~/Desktop/dsmatch-master/data copy/trt_IHAD.Rdata")
load("~/Desktop/dsmatch-master/data copy/yb_IHAD.Rdata")

probit_result=dsmatchATE(YB, Xmat, Trt, method = "dsm", model.ps = "probit", model.pg = "glm", varest = T, cov.balance = T)
xgboost_result=dsmatchATE(YB, Xmat, Trt, method = "dsm", ps = ps, model.pg = "glm", varest = T, cov.balance = T)
rf_result=dsmatchATE(YB, Xmat, Trt, method = "dsm", ps = ps1, model.pg = "glm", varest = T, cov.balance = T)

# best para for xgboost prp
min_num=10
Trt=as.numeric(Trt)

for(i in 1:6){
  for(j in 1:5){
    for(k in 1:9){
      for(l in 1:9){
        eta=0.1+0.04*i
        gamma=0.5+(j-1)*0.4
        lambda=0.2+0.15*k
        alpha=0+(l-1)*0.23

        bst <- xgboost(data =Xmat, label=Trt,max.depth = 2,
                       eta = eta, gamma=gamma,nthread = 6, lambda=lambda,alpha=alpha,
                       nrounds = 1000,objective="binary:logistic")
        pred_s <- predict(bst, Xmat)
        ps=pred_s
        a=dsmatchATE1(ya, Xmat, Trt, method = "dsm", ps = ps, model.pg = "glm", varest = T, cov.balance = T)
       # a=dsmatchATE1(YB, Xmat, Trt, method = "ps", ps = ps,  varest = T, cov.balance = T)
        d=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))
        if(d<min_num){
          eta_x=eta
          gamma_x=gamma
          lambda_x=lambda
          alpha_x=alpha
          min_num=d
        }
      }
    }
  }
}

###

bst_ds <- xgboost(data =Xmat, label=Trt,max.depth = 2,
               eta = 0.22, gamma=1.3,nthread = 6, lambda=0.35,alpha=1.61,
               nrounds = 1500,objective="binary:logistic")
pred_s <- predict(bst_ds, Xmat)
ps=pred_s

bst_ps <- xgboost(data =Xmat, label=Trt,max.depth = 2,
                  eta = 0.38, gamma=1.2,nthread = 6, lambda=0.65,alpha=2.07,
                  nrounds = 1500,objective="binary:logistic")
pred_s <- predict(bst_ps, Xmat)
ps_ps=pred_s

a=dsmatchATE1(ya, Xmat, Trt, method = "dsm", ps = ps, model.pg = "glm", varest = T, cov.balance = T)
a=dsmatchATE1(YB, Xmat, Trt, method = "ps", ps = ps_ps,  varest = T, cov.balance = T)

a=dsmatchATE1(ya, Xmat, Trt, method = "dsm", model.ps="logit", model.pg = "glm", varest = T, cov.balance = T)
a=dsmatchATE1(ya, Xmat, Trt, method = "ps", model.ps = "logit",  varest = T, cov.balance = T)
a=dsmatchATE1(ya, Xmat, Trt, method = "pg", model.pg = "glm", varest = T, cov.balance = T)
d=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))

##


Trt2=as.factor(Trt)
Xmat1=cbind(Xmat,Trt)
Xmat2=cbind(Xmat,matrix_0)
ntree=500
M=randomForest(Xmat1,YB,xtest=Xmat1,ytest=YB,ntree=ntree,mtry=mtry,importance= TRUE,keep.forest=TRUE)
rf_p0=predict(M,newdata=Xmat2)
rf_p1=predict(M,newdata=Xmat3)
pred_pn<-cbind(rf_p0,rf_p1)

a=M$test$votes
ps1=a[,2]
for(i in 1:747){
  if(Trt[i]==1){
    ps1[i]=a[i,2]
  }
  else{
    ps1[i]=a[i,1]
  }
}


#xgboost para for pron

min_num=10
Trt1=as.vector(Trt)
Xmat1=cbind(Xmat,Trt1)
Trt1=as.vector(matrix_0)
matrix_0=matrix(data=rep(0,747),ncol = 1)
Trt1=as.vector(matrix_0)
Xmat2=cbind(Xmat,Trt1)
matrix_1=matrix(data=rep(1,747),ncol = 1)
Trt1=as.vector(matrix_1)
Xmat3=cbind(Xmat,Trt1)

for(i in 1:6){
  for(j in 1:5){
    for(k in 1:9){
      for(l in 1:9){
        Trt=as.numeric(Trt)
        eta=0.1+0.04*i
        gamma=0+(j-1)*0.4
        lambda=0.2+0.25*k
        alpha=0+(l-1)*0.35


        bst <- xgboost(data =Xmat1, label=YB,max.depth = 2,
                       eta = eta, gamma=gamma,nthread = 6, lambda=lambda,alpha=alpha,
                       nrounds = 5000,objective="reg:squarederror")

        pred_s_0 <- predict(bst, Xmat2)
        pred_s_1 <- predict(bst, Xmat3)
        pred_pn<-cbind(pred_s_0,pred_s_1)

        a=dsmatchATE1(ya, Xmat, Trt, method = "dsm", ps = ps, pg = pred_pn, varest = T, cov.balance = T)


        d=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))
        if(d<min_num){
          eta_x=eta
          gamma_x=gamma
          lambda_x=lambda
          alpha_x=alpha
          min_num=d
        }
      }
    }
  }
}

####
###
Trt1=as.vector(Trt)
Xmat1=cbind(Xmat,Trt1)
Trt1=as.vector(matrix_0)
matrix_0=matrix(data=rep(0,747),ncol = 1)
Trt1=as.vector(matrix_0)
Xmat2=cbind(Xmat,Trt1)
matrix_1=matrix(data=rep(1,747),ncol = 1)
Trt1=as.vector(matrix_1)
Xmat3=cbind(Xmat,Trt1)

bst <- xgboost(data =Xmat1, label=ya,max.depth = 4,
               eta = 0.23, gamma=1.2,nthread = 6, lambda=0.7,alpha=2.01,
               nrounds = 3000,objective="reg:squarederror")

pred_s_0 <- predict(bst, Xmat2)
pred_s_1 <- predict(bst, Xmat3)
pred_pn<-cbind(pred_s_0,pred_s_1)

bst_ps <- xgboost(data =Xmat, label=Trt,max.depth = 4,
                  eta = 0.38, gamma=1.2,nthread = 6, lambda=0.8,alpha=2.07,
                  nrounds = 1500,objective="binary:logistic")
pred_s <- predict(bst_ps, Xmat)
ps_ps=pred_s

a=dsmatchATE1(ya, Xmat, Trt, method = "dsm", model.ps = "logit", pg = pred_pn, varest = T, cov.balance = T)
a=dsmatchATE1(ya, Xmat, Trt, method = "pg",  pg = pred_pn,  varest = T, cov.balance = T)

a=dsmatchATE1(ya, Xmat, Trt, method = "dsm", model.ps="logit", model.pg = "glm", varest = T, cov.balance = T)
a=dsmatchATE1(ya, Xmat, Trt, method = "ps", model.ps = "logit",  varest = T, cov.balance = T)
a=dsmatchATE1(ya, Xmat, Trt, method = "pg", model.pg = "glm", varest = T, cov.balance = T)
d=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))



#####
poly1=function(a,b){
  z=0
  for(i in 1:15){

    if(i==1||i==3||i==5||i==7||i==9){
       z=z+(a[i]^2)*b[i]
    }
    else if(i==2||i==4||i==13){
      z=z+(exp(a[i]))*b[i] }

    else{
      z=z+(a[i])*b[i]
    }
  }
  if(a[6]==1){
    z=z+0.5
  }
  if(a[12]==0){
    z=z-1
  }
  return(z)}

###
ya=c()
for (i in 1:747){
   p=matrix(data=sample(x=c(0,1,2,3,4),15,replace=TRUE,prob=c(0.5, 0.2, 0.15, 0.1, 0.05)),ncol=1)
   if(Trt[i]==0){
         #ya[i]=rnorm(1,poly1(Xmat[i,],p),1.5)
         ya[i]=rnorm(1,Xmat[i,]%*%p,1.5)
       }
    else{

      #ya[i]=rnorm(1,poly1(Xmat[i,],p)+4,1.5)
      ya[i]=rnorm(1,(Xmat[i,]%*%p)+4,1.5)
      }
}







   ##  linear xgboost
re=10
ma_linear_causaleffect=matrix(data=rep(1,4*re),ncol=4)
ma_linear_difference=matrix(data=rep(1,4*re),ncol=4)
Trt1=as.vector(Trt)
Xmat1=cbind(Xmat,Trt1)
Trt1=as.vector(matrix_0)
matrix_0=matrix(data=rep(0,747),ncol = 1)
Trt1=as.vector(matrix_0)
Xmat2=cbind(Xmat,Trt1)
matrix_1=matrix(data=rep(1,747),ncol = 1)
Trt1=as.vector(matrix_1)
Xmat3=cbind(Xmat,Trt1)
for(jj in 1:re){
ya=c()
for (i in 1:747){
  p=matrix(data=sample(x=c(0,1,2,3,4),15,replace=TRUE,prob=c(0.5, 0.2, 0.15, 0.1, 0.05)),ncol=1)
  if(Trt[i]==0){
    #ya[i]=rnorm(1,poly1(Xmat[i,],p),1.5)
    ya[i]=rnorm(1,Xmat[i,]%*%p,1)
  }
  else{

    #ya[i]=rnorm(1,poly1(Xmat[i,],p)+4,1.5)
    ya[i]=rnorm(1,(Xmat[i,]%*%p)+4,1)
  }
}


min_num=10
for(i in 1:5){
  for(j in 1:4){
    for(k in 1:5){
      for(l in 1:6){
        eta=0.6+0.05*i
        gamma=0.5+(j-1)*0.4
        lambda=0.4+0.2*k
        alpha=0.6+(l-1)*0.23

        bst <- xgboost(data =Xmat1, label=ya,max.depth = 4,
                       eta = eta, gamma=gamma,nthread = 6, lambda=lambda,alpha=alpha,
                       nrounds = 3000,objective="reg:squarederror",verbose = 0)

        pred_s_0 <- predict(bst, Xmat2)
        pred_s_1 <- predict(bst, Xmat3)
        pred_pn<-cbind(pred_s_0,pred_s_1)

        a=dsmatchATE1(ya, Xmat, Trt, method = "pg",  pg = pred_pn,  varest = T, cov.balance = T)

        d=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))
        if(d<min_num){
          eta_x=eta
          gamma_x=gamma
          lambda_x=lambda
          alpha_x=alpha
          min_num=d
        }

      }}}}

#first ds normal , pn+glm, pn+xg,ds+xg
a=dsmatchATE1(ya, Xmat, Trt, method = "dsm", model.ps = "logit", pg = pred_pn, varest = T, cov.balance = T)
ma_linear_causaleffect[jj,1]=a$est.ds
ma_linear_difference[jj,1]=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))

a=dsmatchATE1(ya, Xmat, Trt, method = "pg", model.pg = "glm", varest = T, cov.balance = T)
ma_linear_difference[jj,2]=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))
ma_linear_causaleffect[jj,2]=a$est.pg

bst <- xgboost(data =Xmat1, label=ya,max.depth = 4,
               eta = eta_x, gamma=gamma_x,nthread = 6, lambda=lambda_x,alpha=alpha_x,
               nrounds = 3000,objective="reg:squarederror",verbose = 0)

pred_s_0 <- predict(bst, Xmat2)
pred_s_1 <- predict(bst, Xmat3)
pred_pn<-cbind(pred_s_0,pred_s_1)
a=dsmatchATE1(ya, Xmat, Trt, method = "pg",  pg = pred_pn,  varest = T, cov.balance = T)
ma_linear_difference[jj,3]=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))
ma_linear_causaleffect[jj,3]=a$est.pg

min_num=10
for(i in 1:5){
  for(j in 1:4){
    for(k in 1:5){
      for(l in 1:6){
        eta=0.6+0.05*i
        gamma=0.5+(j-1)*0.4
        lambda=0.4+0.2*k
        alpha=0.6+(l-1)*0.23

        bst <- xgboost(data =Xmat1, label=ya,max.depth = 4,
                       eta = eta, gamma=gamma,nthread = 6, lambda=lambda,alpha=alpha,
                       nrounds = 3000,objective="reg:squarederror",verbose = 0)

        pred_s_0 <- predict(bst, Xmat2)
        pred_s_1 <- predict(bst, Xmat3)
        pred_pn<-cbind(pred_s_0,pred_s_1)

        a=dsmatchATE1(ya, Xmat, Trt, method = "dsm", model.ps = "logit", pg = pred_pn, varest = T, cov.balance = T)


        d=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))
        if(d<min_num){
          eta_x=eta
          gamma_x=gamma
          lambda_x=lambda
          alpha_x=alpha
          min_num=d
        }

      }}}}

bst <- xgboost(data =Xmat1, label=ya,max.depth = 4,
               eta = eta_x, gamma=gamma_x,nthread = 6, lambda=lambda_x,alpha=alpha_x,
               nrounds = 3000,objective="reg:squarederror",verbose = 0)

pred_s_0 <- predict(bst, Xmat2)
pred_s_1 <- predict(bst, Xmat3)
pred_pn<-cbind(pred_s_0,pred_s_1)
a=dsmatchATE1(ya, Xmat, Trt, method = "dsm", model.ps = "logit", pg = pred_pn, varest = T, cov.balance = T)
ma_linear_difference[jj,4]=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))
ma_linear_causaleffect[jj,4]=a$est.ds
}

##  poly xgboost

ma_poly_causaleffect=matrix(data=rep(1,4*re),ncol=4)
ma_poly_difference=matrix(data=rep(1,4*re),ncol=4)
Trt1=as.vector(Trt)
Xmat1=cbind(Xmat,Trt1)
Trt1=as.vector(matrix_0)
matrix_0=matrix(data=rep(0,747),ncol = 1)
Trt1=as.vector(matrix_0)
Xmat2=cbind(Xmat,Trt1)
matrix_1=matrix(data=rep(1,747),ncol = 1)
Trt1=as.vector(matrix_1)
Xmat3=cbind(Xmat,Trt1)
for(jj in 1:re){
  ya=c()
  for (i in 1:747){
    p=matrix(data=sample(x=c(0,1,2,3,4),15,replace=TRUE,prob=c(0.5, 0.2, 0.15, 0.1, 0.05)),ncol=1)
    if(Trt[i]==0){
      ya[i]=rnorm(1,poly1(Xmat[i,],p),1)

    }
    else{
      ya[i]=rnorm(1,poly1(Xmat[i,],p)+4,1)

    }
  }


  min_num=10
  for(i in 1:5){
    for(j in 1:4){
      for(k in 1:5){
        for(l in 1:6){
          eta=0.6+0.05*i
          gamma=0.5+(j-1)*0.4
          lambda=0.4+0.2*k
          alpha=0.6+(l-1)*0.23

          bst <- xgboost(data =Xmat1, label=ya,max.depth = 4,
                         eta = eta, gamma=gamma,nthread = 6, lambda=lambda,alpha=alpha,
                         nrounds = 3000,objective="reg:squarederror",verbose = 0)

          pred_s_0 <- predict(bst, Xmat2)
          pred_s_1 <- predict(bst, Xmat3)
          pred_pn<-cbind(pred_s_0,pred_s_1)

          a=dsmatchATE1(ya, Xmat, Trt, method = "pg",  pg = pred_pn,  varest = T, cov.balance = T)

          d=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))
          if(d<min_num){
            eta_x=eta
            gamma_x=gamma
            lambda_x=lambda
            alpha_x=alpha
            min_num=d
          }

        }}}}

  #first ds normal , pn+glm, pn+xg,ds+xg
  a=dsmatchATE1(ya, Xmat, Trt, method = "dsm", model.ps = "logit", pg = pred_pn, varest = T, cov.balance = T)
  ma_poly_causaleffect[jj,1]=a$est.ds
  ma_poly_difference[jj,1]=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))

  a=dsmatchATE1(ya, Xmat, Trt, method = "pg", model.pg = "glm", varest = T, cov.balance = T)
  ma_poly_difference[jj,2]=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))
  ma_poly_causaleffect[jj,2]=a$est.pg

  bst <- xgboost(data =Xmat1, label=ya,max.depth = 4,
                 eta = eta_x, gamma=gamma_x,nthread = 6, lambda=lambda_x,alpha=alpha_x,
                 nrounds = 3000,objective="reg:squarederror",verbose = 0)

  pred_s_0 <- predict(bst, Xmat2)
  pred_s_1 <- predict(bst, Xmat3)
  pred_pn<-cbind(pred_s_0,pred_s_1)
  a=dsmatchATE1(ya, Xmat, Trt, method = "pg",  pg = pred_pn,  varest = T, cov.balance = T)
  ma_poly_difference[jj,3]=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))
  ma_poly_causaleffect[jj,3]=a$est.pg

  min_num=10
  for(i in 1:5){
    for(j in 1:4){
      for(k in 1:5){
        for(l in 1:6){
          eta=0.6+0.05*i
          gamma=0.5+(j-1)*0.4
          lambda=0.4+0.2*k
          alpha=0.6+(l-1)*0.23

          bst <- xgboost(data =Xmat1, label=ya,max.depth = 4,
                         eta = eta, gamma=gamma,nthread = 6, lambda=lambda,alpha=alpha,
                         nrounds = 3000,objective="reg:squarederror",verbose = 0)

          pred_s_0 <- predict(bst, Xmat2)
          pred_s_1 <- predict(bst, Xmat3)
          pred_pn<-cbind(pred_s_0,pred_s_1)

          a=dsmatchATE1(ya, Xmat, Trt, method = "dsm", model.ps = "logit", pg = pred_pn, varest = T, cov.balance = T)


          d=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))
          if(d<min_num){
            eta_x=eta
            gamma_x=gamma
            lambda_x=lambda
            alpha_x=alpha
            min_num=d
          }

        }}}}

  bst <- xgboost(data =Xmat1, label=ya,max.depth = 4,
                 eta = eta_x, gamma=gamma_x,nthread = 6, lambda=lambda_x,alpha=alpha_x,
                 nrounds = 3000,objective="reg:squarederror",verbose = 0)

  pred_s_0 <- predict(bst, Xmat2)
  pred_s_1 <- predict(bst, Xmat3)
  pred_pn<-cbind(pred_s_0,pred_s_1)
  a=dsmatchATE1(ya, Xmat, Trt, method = "dsm", model.ps = "logit", pg = pred_pn, varest = T, cov.balance = T)
  ma_poly_difference[jj,4]=sum(abs(a$mear[2,]))-sum(abs(a$mear[1,]))
  ma_poly_causaleffect[jj,4]=a$est.ds
}

write.csv(ma_poly_difference,file="pd")
write.csv(ma_linear_difference,file="ld")
write.csv(ma_poly_causaleffect,file="pc")
write.csv(ma_linear_causaleffect,file="pl")


